README

Para utilizar a aplicação é necessário ter a framework NewtonSoft.

É também necessário atualizar as diretorias de importação e criação dos devidos documentos.