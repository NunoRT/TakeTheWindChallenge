﻿using System;
using System.Linq;
using System.Dynamic;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace ChallengeTaketheWind
{
    class Challenge
    {
        static void Main(string[] args)
        {
            var doc = XDocument.Load(@"/Users/nuno/Downloads/Challenge.xml");
            var nodes = from node in doc.Descendants("vehicles") select node;
            string fileName = @"/Users/nuno/Projects/Challenge2/Challenge2/Challenge.json";


            var id = 0;
            var Value = "";
            var name = "";

            foreach (var child in nodes.Descendants())
            {

                if (child.Name.ToString() == "vehicle")
                {
                    id += 1;
                    var elem = new XElement("id", id);

                    child.AddFirst(elem);
                }

                if (child.Name.ToString() == "motor")
                {
                    if (Value == "truck")
                    {
                        var elem3 = new XElement("displacement", "3000");
                        child.AddFirst(elem3);

                    }
                }

                foreach (var att in child.Attributes())
                {
                    name = att.Name.ToString();
                    Value = att.Value.ToString();


                    if (Value == "hybrid")
                    {
                        var elem2 = new XElement("color", "red");
                        child.AddAfterSelf(elem2);
                    }

                    if (child.Name.ToString() == "wheel")
                    {
                        if (Value == "14" && name == "size")
                        {
                            var att2 = new XAttribute(name, Value);
                            var att1 = new XAttribute("pressure", "50");
                            child.ReplaceAttributes(att2, att1);

                        }

                    }

                }

            }

            doc.Save(@"/Users/nuno/Projects/Challenge2/Challenge2/Challenge2.xml");
            var doc2 = XDocument.Load(@"/Users/nuno/Projects/Challenge2/Challenge2/Challenge2.xml");
            string json = JsonConvert.SerializeObject(doc2);
            //Console.WriteLine(json);
            File.WriteAllText(fileName, json);
            File.Delete(@"/Users/nuno/Projects/Challenge2/Challenge2/Challenge2.xml");
        }
    }
}